# ventral_api_client/config.py

DEFAULT_BASE_URL = "http://kontakt.mine.nu:4411"
