# ventral_api_client/__init__.py

from .ventral import VisionAPIClient  # Exposes only the client
